﻿using System;
using SendGrid;
using SendGrid.Helpers.Mail;

using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Execute().Wait();
        }
        static async Task Execute()
        {
            var apiKey = "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";
                //Environment.GetEnvironmentVariable("NAME_OF_THE_ENVIRONMENT_VARIABLE_FOR_YOUR_SENDGRID_KEY");
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("girijacoelho@gmail.com", "Girija Prabhakaran");
            var subject = "third time";
            var to = new EmailAddress("girija28@gmail.com", "Example User");
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = "<strong>and easy to do anywhere, even with C#</strong>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
        }
    }
}
